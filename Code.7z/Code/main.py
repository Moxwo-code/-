#Ссылка на GitHub: https://github.com/Moxwo-code < Создатель кода
#Ссылка для донатов: https://t.me/send?start=IVxrk3WxDDd2

import csv
import re

Base = ["ABC-3xx.csv", "ABC-4xx.csv", "ABC-8xx.csv", "DEF-9xx.csv"]

def search(phone_number):
    phone_clean = re.sub(r'\D', '', phone_number)

    if phone_clean.startswith('8') and len(phone_clean) == 11:
        phone_clean = '7' + phone_clean[1:]
    elif len(phone_clean) == 10:
        phone_clean = '7' + phone_clean

    if len(phone_clean) != 11:
        print("❌ Неверный формат номера! Введите российский номер телефона в форматах: 79012345678 | +79012345678")
        return

    abc = phone_clean[1:4]
    try:
        number_to_find = int(phone_clean[4:])
    except ValueError:
        print(f"❌ Ошибка. Неверный номер!")
        return

    for filename in Base:
        try:
            with open(filename, "r", encoding="utf-8") as file:
                reader = csv.reader(file, delimiter=";")

                header = next(reader, None)

                for row in reader:
                    if len(row) < 8:
                        continue

                    try:
                        operator_code = row[0].strip()
                        range_from = int(row[1].strip())
                        range_to = int(row[2].strip())
                    except (ValueError, IndexError):
                        continue

                    if operator_code == abc and range_from <= number_to_find <= range_to:
                        print(f"""\nНомер телефона: {phone_clean}
Код оператора: {operator_code}
Диапозон: {range_from}-{range_to}
Ёмкость: {row[3]}
Оператор: {row[4]}
Регион: {row[5]}
Территория ГАР: {row[6]}
ИНН: {row[7]}""")
                        return

        except FileNotFoundError:
            print(f"❌ Ошибка. Файл базы: {filename} не найден!")
        except Exception as e:
            print(f"❌ Ошибка при чтении файла {filename}. Ошибка: {e}")

def main():
    print("Здравствуйте, введите российский номер телефона в форматах: 79012345678 | +79012345678")

    while True:
        phone = input("\nВведите российский номер телефона: ")

        if not phone:
            print("❌ Введите российский номер телефона в форматах: 79012345678 | +79012345678")
            continue

        search(phone)

if __name__ == "__main__":
    main()