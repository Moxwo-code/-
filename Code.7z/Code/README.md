# Phone Operator Search System
# Requires Python 3.14

# Standard library dependencies:
# - csv
# - re

# Для корректной работы убедитесь, что файлы баз данных находятся в той же директории:
# ABC-3xx.csv, ABC-4xx.csv, ABC-8xx.csv, DEF-9xx.csv